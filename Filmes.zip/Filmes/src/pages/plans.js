import Footer from './../components/Footer/index';

const planos = [{
    "nome": "Plano Básico",
    "preco": "25,90",
    "detalhes": "Acesso a todo o catálogo de filmes e séries em qualidade SD (definição padrão). Permite o download de até 5 títulos por mês para assistir offline."
},
{
    "nome": "Plano Padrão",
    "preco": "42,90",
    "detalhes": "Acesso a todo o catálogo de filmes e séries em qualidade HD (alta definição). Permite o download de até 10 títulos por mês para assistir offline."
},
{
    "nome": "Plano Premium",
    "preco": "55,90",
    "detalhes": "Acesso a todo o catálogo de filmes e séries em qualidade HD e 4K Ultra HD (resolução muito alta). Permite o download de até 20 títulos por mês para assistir offline."
},
]

export default function Plans() {
    return (
        

        <div className="container text-center">
        <div class="row">

        <div class="custom-title px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
                <h1 class="display-4">Planos disponíveis</h1>
                <p class="lead">Atualmente temos disponíveis os planos listados abaixo.</p>
        </div>

            {planos.map((plano, i) => (
                <div className="col-4" key={i}>
                <div className="card">
                    <div className="card-body">
                    <h5 className="card-title">{plano.nome} </h5>
                    <p>{plano.preco}</p>
                    <p>{plano.detalhes}</p>
                    <a
                        href={`href={details/${plano.nome}`}
                    >
                        <div className="btn btn-primary">
                        Adquirir
                        </div>
                    </a>
                    </div>
                </div>
                </div>
            ))}
            </div>
            </div>
                )
            }