import React from 'react';
export default function Error() {
    return (
        <div class="container">
        <div class="custom-title px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
                <h1 class="display-4">Página não encontrada</h1>
            </div>
            </div>
    );
}