import { useParams } from "react-router-dom";
import "./about.css";

export default function About() {

    return (
        <div class="container">
            <div class="custom-title px-3 py-3 pt-md-5 pb-md-4 mx-auto text-center">
                <h1 class="display-4">Sobre</h1>
            </div>
            <div class= "container1">
                <p class="p">Bem-vindo ao nosso site de filmes! <br/>
                    Nós somos apaixonados por cinema e acreditamos que não há nada melhor do que sentar-se 
                    em frente à tela grande e deixar-se envolver pela história que está sendo contada. 
                    Nós criamos este site para compartilhar essa paixão com vocês, nossos espectadores. <br/>
                    Nós temos uma ampla seleção de filmes, desde os clássicos até os mais recentes 
                    lançamentos, com opções em todos os gêneros e para todas as idades. Nós queremos 
                    proporcionar a vocês a melhor experiência possível, com a mais alta qualidade de imagem 
                    e som. <br/>
                    Nosso objetivo é tornar o cinema acessível a todos, por isso estamos sempre buscando 
                    novas formas de expandir nosso alcance. Estamos constantemente atualizando nosso 
                    catálogo e adicionando novas funcionalidades ao site, para que vocês possam desfrutar 
                    de filmes em qualquer lugar e a qualquer hora. <br/>
                    Nosso site é feito para vocês, nossos espectadores. Nós queremos ouvir o que vocês têm 
                    a dizer e como podemos melhorar sua experiência. Se tiverem alguma sugestão ou 
                    comentário, por favor, não hesitem em entrar em contato conosco. <br/>

                    Esperamos que vocês gostem de navegar em nosso site, descobrir novos filmes e compartilhar nossa paixão pelo cinema. Obrigado por nos escolherem como seu destino para entretenimento cinematográfico e esperamos vê-los em breve no cinema!</p>
                <img src={'/assets/images/logo.png'} className="card-img-top1" />    
            </div>
        </div>
        
    )
}