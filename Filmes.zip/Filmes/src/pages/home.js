import Title from '../components/Title';
import Filme from './../components/Filme/index';

export default function Home() {
    return (
        <div class="container">
            <Title/>
            <Filme/>
        </div>
    )
}