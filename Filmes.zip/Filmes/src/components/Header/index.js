import "./Header.css";

export default function Header() {
    return (<header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
          <div class="container-fluid">
            <button
              class="navbar-toggler"
              type="button"
              data-mdb-toggle="collapse"
              data-mdb-target="#navbarExample01"
              aria-controls="navbarExample01"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarExample01">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item active">
                  <a class="nav-link" aria-current="page" href="#">Home</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Features</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">Pricing</a>
                </li>
                <li class="nav-item">
                  <a class="nav-link" href="#">About</a>
                </li>
              </ul>
            </div>
          </div>
        </nav>
      </header>
    )

        // <div class="container">
        //     <header class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 mb-4 border-bottom">
        //         <a href="/" class="d-flex align-items-center col-md-3 mb-2 mb-md-0 text-dark text-decoration-none">
        //             <svg class="bi me-2" width="40" height="32" role="img" aria-label="Bootstrap"></svg>
        //         </a>

        //         <ul class="nav col-12 col-md-auto mb-2 justify-content-center mb-md-0">
        //             <li><a href="#" class="nav-link px-2 link-secondary">Home</a></li>
        //             <li><a href="#" class="nav-link px-2 link-dark">Preços</a></li>
        //             <li><a href="#" class="nav-link px-2 link-dark">Sobre</a></li>
        //         </ul>

        //         <div class="col-md-3 text-end">
        //             <button type="button" class="btn btn-outline-primary me-2">Login</button>
        //             <button type="button" class="btn btn-primary">Cadastrar</button>
        //         </div>
        //     </header>
        // </div>
    //)
}