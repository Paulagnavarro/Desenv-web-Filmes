import "./Filme.css";

const filmes = [{
  "nome": "Lucy",
  "duracao": "1H29",
  "foto": "lucy.png",
},
{
  "nome": "Avatar",
  "duracao": "3H12",
  "foto": "avatar.png",
},
{
  "nome": "Harry Potter e o Prisioneiro de Azkaban",
  "duracao": "2H22",
  "foto": "harry_potter.png",
},
{
  "nome": "Orgulho e Preconceito",
  "duracao": "2H09",
  "foto": "orgulho_e_preconceito.png",
},
{
  "nome": "Homem Aranha: Longe de casa",
  "duracao": "2H09",
  "foto": "homem-aranha.png",
},
{
  "nome": "Vingadores: Ultimato",
  "duracao": "3H02",
  "foto": "vingadores.png",
},

]

export default function Filme() {
  return (
    <div className="container text-center">
      <div class="row">

        {filmes.map((filme, i) => (
          <div className="col-4" key={i.toString}>
            <div className="card">
              <img src={'/assets/images/' + filme.foto} alt={filme.nome} className="card-img-top" />
              <div className="card-body">
                <h5 className="card-title">{filme.nome} </h5>
                <p>{filme.duracao}</p>
                <a
                  href={`/details/${filme.nome}`}
                >
                  <div className="btn btn-primary">
                    Detalhes
                  </div>
                </a>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}