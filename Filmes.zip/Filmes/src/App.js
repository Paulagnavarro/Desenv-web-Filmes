import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import Home from './pages/home';
import About from './pages/about';
import Plans from './pages/plans';
import Error from './pages/Error';
import Details from './pages/Details/details';
import Footer from './components/Footer/index';

export default function App() {
    return (
        <Router>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
          <div class="container-fluid">
            <button
              class="navbar-toggler"
              type="button"
              data-mdb-toggle="collapse"
              data-mdb-target="#navbarExample01"
              aria-controls="navbarExample01"
              aria-expanded="false"
              aria-label="Toggle navigation"
            >
              <i class="fas fa-bars"></i>
            </button>
            <div class="collapse navbar-collapse" id="navbarExample01">
              <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item active">
                     <Link className="nav-item nav-link" to='/'>Home</Link>
                </li>
                <li class="nav-item">
                    <Link className="nav-item nav-link" to='/about/Paula'>About</Link>
                </li>
                <li class="nav-item">
                <Link className="nav-item nav-link" to='/plans'>Plans</Link>
                </li>
              </ul>
            </div>
          </div>
          </nav>

        <Routes>
            <Route path='/' element={<Home />} />
            <Route path='/about/:name' element={<About/>} />
            <Route path='/plans' element={<Plans/>} />
            <Route path='details/:filme' element={<Details />} />
            <Route path="*" element={<Error />} />
        </Routes>
        
        <Footer/>
        
        </Router>
    )
}